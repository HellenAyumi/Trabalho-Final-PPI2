<?php
  define('HOST', 'localhost');
  define('DATABASE', 'BANCO_INSIDE_SPORTS');
  define('USER', 'root');
  define('PASSWORD', '');
?>